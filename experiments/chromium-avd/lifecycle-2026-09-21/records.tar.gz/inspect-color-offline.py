#!/usr/bin/env python3
"""Compare retained flat patches with decoded YUV and explicit matrix models."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
clip = Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')


def decode(args):
    return subprocess.check_output(['ffmpeg', '-v', 'error', '-threads', '1', *args,
        '-threads', '1', '-f', 'rawvideo', 'pipe:1'], timeout=15)


yuv = decode(['-i', str(clip), '-vf', "select=eq(n\\,30)", '-frames:v', '1', '-pix_fmt', 'yuv420p'])
assert len(yuv) == 640 * 360 * 3 // 2
images = {m: decode(['-i', str(ROOT / ('lifecycle-' + m + '-01') / 'seek-1.png'),
                    '-pix_fmt', 'rgb24']) for m in ('software', 'hardware')}
observations = []
for x in (50, 160, 270, 370, 480, 590):
    y = 100
    Y, U, V = yuv[y * 640 + x], yuv[640*360 + (y//2)*320 + x//2], yuv[640*360*5//4 + (y//2)*320 + x//2]
    luma, cb, cr = (Y-16)*255/219, (U-128)*255/224, (V-128)*255/224
    models = {}
    for label, kr, kb in [('bt601', .299, .114), ('bt709', .2126, .0722)]:
        kg = 1-kr-kb
        values = (luma + 2*(1-kr)*cr,
                  luma - 2*kb*(1-kb)/kg*cb - 2*kr*(1-kr)/kg*cr,
                  luma + 2*(1-kb)*cb)
        models[label] = [round(min(255, max(0, c))) for c in values]
    offset = ((y*2)*1280 + x*2)*3
    observations.append({'source_xy': [x, y], 'yuv': [Y,U,V], 'simple_matrix_rgb': models,
        'browser_rgb': {m:list(rgb[offset:offset+3]) for m,rgb in images.items()}})
result = {'scope':'Offline retained-frame diagnostics; matrix models exclude transfer/primary conversion and quantization',
    'fixture_has_colr_bytes': b'colr' in clip.read_bytes(), 'patches':observations,
    'hardware_access':False}
with (ROOT/'lifecycle-color-observations-01.json').open('x') as f:
    json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
