#!/usr/bin/env python3
"""Offline exact RGB comparison; differences are measured, never tuned away."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess

ROOT = Path(__file__).resolve().parent
NAMES = ['seek-1', 'seek-4', 'seek-2', 'seek-6', 'reopen-1']


def events(mode):
    return [json.loads(s) for s in (ROOT / ('lifecycle-' + mode + '-01') / 'events.jsonl').read_text().splitlines()]


def main():
    rows = {m: json.loads((ROOT / ('lifecycle-' + m + '-result-01.json')).read_text()) for m in ('software', 'hardware')}
    assert all(r['accepted'] for r in rows.values()), 'Execution gates did not pass'
    assert rows['software']['identity'] == rows['hardware']['identity'], 'Identity mismatch'
    ev = {m: events(m) for m in rows}
    identities = {m: next(e for e in records if e['kind'] == 'identity') for m, records in ev.items()}
    for key in ('clip_sha256', 'driver_sha256'):
        assert identities['software'][key] == identities['hardware'][key], key
    captures = {m: {e['name']: e for e in records if e['kind'] == 'capture'} for m, records in ev.items()}
    assert all(set(c) == set(NAMES) for c in captures.values()), 'Capture set mismatch'
    arrays, report = {}, []
    for mode in rows:
        arrays[mode] = {}
        for name in NAMES:
            path = ROOT / ('lifecycle-' + mode + '-01') / (name + '.png')
            assert hashlib.sha256(path.read_bytes()).hexdigest() == captures[mode][name]['sha256']
            raw = path.read_bytes()
            assert raw[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', raw[16:24]) == (1280, 720)
            rgb = subprocess.check_output(['ffmpeg', '-v', 'error', '-threads', '1', '-i', str(path),
                '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-threads', '1', 'pipe:1'], timeout=15)
            assert len(rgb) == 1280 * 720 * 3
            arrays[mode][name] = rgb
    for name in NAMES:
        left, right = arrays['software'][name], arrays['hardware'][name]
        assert captures['software'][name]['display'] == captures['hardware'][name]['display'], 'Display/time mismatch'
        delta = bytes(abs(a - b) for a, b in zip(left, right))
        pixels = zip(delta[0::3], delta[1::3], delta[2::3])
        differing = large = 0
        for values in pixels:
            differing += max(values) != 0
            large += max(values) > 8
        report.append({'capture': name, 'exact_rgb_match': left == right,
            'mean_absolute_channel_error_255': sum(delta) / len(delta),
            'max_channel_error_255': max(delta),
            'different_pixels': differing,
            'pixels_with_channel_error_gt_8': large,
            'pixel_count': 1280 * 720,
            'software_png_sha256': captures['software'][name]['sha256'],
            'hardware_png_sha256': captures['hardware'][name]['sha256']})
    invariants = {}
    for mode in rows:
        hashes = [hashlib.sha256(arrays[mode][name]).hexdigest() for name in NAMES[:4]]
        invariants[mode] = {'four_distinct_seek_frames': len(set(hashes)) == 4,
            'reopen_matches_first_seek': arrays[mode]['seek-1'] == arrays[mode]['reopen-1']}
    result = {'criterion': 'Exact decoded RGB equality of all five same-client captures; no tolerance-adjusted pass',
        'execution_passed': True, 'samples': report, 'invariants': invariants,
        'exact_comparison_passed': all(r['exact_rgb_match'] for r in report) and all(all(v.values()) for v in invariants.values()),
        'limit': 'Software parity is not independent BT.709 color accuracy, broader format or daily-browser qualification'}
    with (ROOT / 'lifecycle-pixel-comparison-01.json').open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps(result, indent=2))
    return 0 if result['exact_comparison_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
