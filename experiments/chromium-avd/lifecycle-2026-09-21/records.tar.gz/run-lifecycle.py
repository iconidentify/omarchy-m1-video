#!/usr/bin/env python3
"""One candidate launch; strict final observation also covers guard exceptions."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from dataclasses import asdict

from privileged_observer import LinuxBackend
import hwguard

ROOT = Path(__file__).resolve().parent
MODE = sys.argv[1] if len(sys.argv) == 2 else ''
if MODE not in ('software', 'hardware'):
    raise SystemExit('Expected software or hardware')
OUT = ROOT / ('lifecycle-' + MODE + '-01')
RECEIPT = ROOT / ('lifecycle-' + MODE + '-result-01.json')
BACKENDS = []


class TrackedBackend(LinuxBackend):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        BACKENDS.append(self)


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def clean(state):
    return bool(state.module_loaded and state.video_node == '/dev/video0'
                and state.media_node == '/dev/media0' and not state.holders
                and not state.stuck_tasks and not state.faults)


def group_members(owner):
    """Only the guard child's new session/group, excluding exited zombies."""
    if not owner:
        return []
    found = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().rsplit(')', 1)[-1].split()
            if int(fields[2]) == owner and int(fields[3]) == owner and fields[0] != 'Z':
                if proc.stat().st_uid != os.getuid():
                    raise RuntimeError('Cannot verify remaining process ownership')
                found.append(int(proc.name))
        except FileNotFoundError:
            pass
    return found


def verify():
    if not __debug__ or sys.flags.optimize or os.geteuid() == 0:
        raise RuntimeError('Requires unprivileged Python with assertions enabled')
    if OUT.exists() or RECEIPT.exists():
        raise RuntimeError('Single-attempt output exists; refusing automatic retry')
    for key in ('PYTHONOPTIMIZE', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT',
                'MESA_SHADER_CACHE_DISABLE'):
        os.environ.pop(key, None)
    os.environ.update(MESA_DISK_CACHE_MULTI_FILE='0', MESA_DISK_CACHE_DATABASE='0',
                      MESA_DISK_CACHE_SINGLE_FILE='0', LIBVA_DRIVER_NAME='v4l2_request',
                      LIBVA_DRIVERS_PATH='/usr/lib/dri')
    if os.uname().machine != 'aarch64' or b'apple,' not in Path('/proc/device-tree/compatible').read_bytes():
        raise RuntimeError('Not the selected Apple ARM64 host')
    packages = subprocess.check_output(['pacman', '-Q', 'linux-asahi', 'mesa', 'libva',
        'libva-v4l2_request-avd', 'libdrm', 'nss', 'glibc', 'qt6-base'], text=True, timeout=5)
    units = subprocess.check_output(['systemctl', '--user', 'list-units', '--type=service',
        '--state=active,activating', '--no-legend', '--plain'], text=True, timeout=5)
    if any('omarchy-video-build' in line or 'bounded-build' in line or 'm1-chromium' in line for line in units.splitlines()):
        raise RuntimeError('A shared desktop build is active')
    prior = json.loads((ROOT / 'runtime-verified.json').read_text())
    if packages != prior['packages'] or os.uname().release != prior['kernel']:
        raise RuntimeError('System identity changed since loader verification')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != prior['boot_id']:
        raise RuntimeError('Boot changed since verification')
    for name, expected in prior['files_verified'].items():
        path = ROOT / 'browser' / name
        if not path.resolve().is_relative_to(ROOT / 'browser') or path.stat().st_mode & 0o6000 or digest(path) != expected:
            raise RuntimeError('Runtime file identity changed: ' + name)
    for key, record in prior['system_files'].items():
        if digest(record['path']) != record['sha256']:
            raise RuntimeError('System/helper identity changed: ' + key)
    if digest(ROOT / 'lifecycle-v1.py') != '88ebb0271fa7616311d6fe2cdd23ee524734d49065d987f451a30333c0d32ebd':
        raise RuntimeError('Selection harness changed after review')
    metadata = Path('<HOME>/src/m1-chromium-access-artifacts-20260920/inspect-metadata')
    if digest(metadata) != '2919985e561869c12d6ede1b44ce52dda9c8e04f76e00c926f0e05f452d0cd08':
        raise RuntimeError('Metadata helper identity changed')
    if subprocess.check_output([str(metadata)], text=True, timeout=10).splitlines() != prior['metadata_selection']:
        raise RuntimeError('Metadata selection changed')
    clip = Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')
    if digest(clip) != 'befc52cf1eabc751f35ba254c47943b252cc93601724f015871f114d3da4dc0a':
        raise RuntimeError('Pinned fixture changed')
    return {'clip_sha256': digest(clip), 'boot_id': prior['boot_id'], 'kernel': prior['kernel'], 'packages': packages,
            'browser_sha256': prior['files_verified']['chrome'],
            'launcher_sha256': digest(__file__), 'observer_sha256': digest(ROOT / 'privileged_observer.py'),
            'harness_sha256': digest(ROOT / 'lifecycle-v1.py')}


def main():
    identity = verify()
    if MODE == 'hardware':
        reference = json.loads((ROOT / 'lifecycle-software-result-01.json').read_text())
        if not reference['accepted'] or reference['identity'] != identity:
            raise RuntimeError('Successful identical-build software reference required')
    receipt = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'identity': identity, 'mode': MODE, 'accepted': False, 'forced_outer_cleanup': False,
               'deadline_note': '90-second guard deadline plus bounded observation/cleanup time'}
    # Reserve the attempt before any launch, including preflight failures.
    with RECEIPT.open('x') as f:
        json.dump(receipt, f, indent=2)
    old_backend = hwguard.LinuxBackend
    try:
        before = LinuxBackend().state()
        receipt['preflight'] = asdict(before)
        if not clean(before):
            raise RuntimeError('Strict preflight refused')
        hwguard.LinuxBackend = TrackedBackend
        result = hwguard.run_guarded([sys.executable, str(ROOT / 'lifecycle-v1.py'),
            MODE, str(OUT)], identity='avd', deadline=90, poll=0.5,
            log_path=ROOT / ('lifecycle-' + MODE + '-guard-01.jsonl'), env=os.environ.copy())
        receipt['guard'] = asdict(result)
    except BaseException as exc:
        receipt['error'] = repr(exc)
    finally:
        hwguard.LinuxBackend = old_backend
        # This check deliberately includes owned clients and whole-boot faults.
        try:
            receipt['after_guard'] = asdict(LinuxBackend().state())
        except BaseException as exc:
            receipt['observation_error'] = repr(exc)
        try:
            owner = next((b.owner_pid for b in reversed(BACKENDS) if b.owner_pid), None)
            remaining = group_members(owner)
            receipt['remaining_guard_group'] = remaining
            if remaining:
                receipt['forced_outer_cleanup'] = True
                for sig, seconds in ((signal.SIGTERM, 2), (signal.SIGKILL, 3)):
                    if not group_members(owner):
                        break
                    try:
                        os.killpg(owner, sig)
                    except ProcessLookupError:
                        break
                    until = time.monotonic() + seconds
                    while group_members(owner) and time.monotonic() < until:
                        time.sleep(0.1)
            receipt['surviving_guard_group'] = group_members(owner)
        except BaseException as exc:
            receipt['cleanup_error'] = repr(exc)
        try:
            final = LinuxBackend().state()
            receipt['final_all_holder_state'] = asdict(final)
            events = [json.loads(line) for line in (OUT / 'events.jsonl').read_text().splitlines()] if (OUT / 'events.jsonl').exists() else []
            completed = [e for e in events if e['kind'] == 'completed']
            exits = [e for e in events if e['kind'] == 'browser_exit']
            guard = receipt.get('guard', {})
            receipt['accepted'] = bool(
                not any(k in receipt for k in ('error', 'observation_error', 'cleanup_error'))
                and guard.get('status') == 'ok' and guard.get('returncode') == 0
                and not receipt['forced_outer_cleanup'] and not receipt.get('surviving_guard_group')
                and len(completed) == 1 and all(completed[0].get(k) is True for k in
                    ('passed_execution', 'all_holders_idle', 'normal_browser_exit'))
                and len(exits) == 1 and exits[0].get('close_requested') is True
                and exits[0].get('forced_cleanup') is False and exits[0].get('returncode') == 0
                and not any(e['kind'] in ('failure', 'teardown_failure') for e in events)
                and len([e for e in events if e['kind'] == 'seek']) == 20
                and len([e for e in events if e['kind'] == 'capture']) == 5
                and len([e for e in events if e['kind'] == 'play_all']) == 1
                and len([e for e in events if e['kind'] == 'reopen']) == 1
                and clean(final))
        except BaseException as exc:
            receipt['final_error'] = repr(exc)
            receipt['accepted'] = False
        receipt['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2), flush=True)
    return 0 if receipt['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
