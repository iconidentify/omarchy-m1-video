#!/usr/bin/env python3
"""Read-only root /proc observer for the existing guard; browser stays unprivileged."""
import argparse
import json
import os
import stat
from pathlib import Path
import subprocess
import sys
from dataclasses import asdict

sys.path.insert(0, '<HOME>/src/driver-m1-candidate-20260920/tests')
import hwguard


def collect_process_state(nodes, owner_pid):
    """Inspect each FD separately; one closing FD cannot hide another FD."""
    devices = {Path(node).stat().st_rdev for node in nodes}
    holders, stuck = [], []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            matches = []
            for fd in (proc / 'fd').iterdir():
                try:
                    info = fd.stat()
                    if stat.S_ISCHR(info.st_mode) and info.st_rdev in devices:
                        matches.append(os.readlink(fd))
                except FileNotFoundError:
                    pass
            if matches:
                pid = int(proc.name)
                holders.append({'pid': pid, 'pgrp': hwguard.process_group(pid),
                    'owner_root': owner_pid if owner_pid and hwguard.is_owned_holder(pid, owner_pid) else None,
                    'device_paths': sorted(set(matches))})
            for task in (proc / 'task').iterdir():
                try:
                    wchan = (task / 'wchan').read_text().strip()
                    text = (task / 'stat').read_text()
                    if any(token in wchan for token in hwguard.DECODER_WCHANS):
                        stuck.append({'pid': int(proc.name), 'tid': int(task.name),
                                      'state': text.rsplit(')', 1)[-1].split()[0], 'wchan': wchan})
                except FileNotFoundError:
                    pass
        except FileNotFoundError:
            pass
    return holders, stuck


class LinuxBackend(hwguard.LinuxBackend):
    def state(self):
        result = subprocess.run(
            ['sudo', '-n', sys.executable, str(Path(__file__).resolve()),
             '--state', '--owner', str(self.owner_pid or 0)],
            text=True, capture_output=True, timeout=20)
        if result.returncode:
            raise hwguard.GuardError('Privileged observation failed: ' + result.stderr[-1000:])
        data = json.loads(result.stdout)
        if data['uid'] != 0 or data['visibility'] != 'checked':
            raise hwguard.GuardError('Unverified observer visibility')
        return hwguard.DecoderState(**data['state'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', action='store_true', required=True)
    parser.add_argument('--owner', type=int, default=0)
    args = parser.parse_args()
    assert os.geteuid() == 0 and args.owner >= 0
    video = media = None
    for dev in sorted(Path('/sys/class/video4linux').glob('video*')):
        if (dev / 'name').read_text().strip() == 'avd':
            video = '/dev/' + dev.name
            for node in (dev / 'device').glob('media*'):
                media = '/dev/' + node.name
    holders, stuck = collect_process_state([n for n in [video, media] if n], args.owner or None)
    state = hwguard.DecoderState(Path('/sys/module/apple_avd').exists(), video, media,
                                holders, stuck, hwguard.LinuxBackend().journal_since())
    print(json.dumps({'uid': os.geteuid(), 'visibility': 'checked',
                      'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                      'state': asdict(state)}))
