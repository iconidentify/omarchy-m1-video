#!/usr/bin/env python3
"""Offline syntax/dependency and fixture inspection before hardware work."""
from pathlib import Path
import hashlib
import json
import subprocess
import ast

root = Path(__file__).resolve().parent
files = ['lifecycle-v1.py', 'run-lifecycle.py', 'compare-lifecycle.py', 'privileged_observer.py']
hashes = {}
for name in files:
    path = root / name
    compile(path.read_text(), str(path), 'exec')
    hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
clip = Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')
probe = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
    '-show_streams', '-of', 'json', str(clip)], text=True, timeout=10)
module = ast.parse((root / 'lifecycle-v1.py').read_text())
function = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'current_player_properties')
namespace = {}
exec(compile(ast.Module(body=[function], type_ignores=[]), '<selection gate>', 'exec'), namespace)
gate = namespace['current_player_properties']
old = {'kVideoDecoderName': 'VaapiVideoDecoder', 'kIsPlatformVideoDecoder': 'true', 'kFrameUrl': 'file:///test'}
assert gate({'old'}, {'old'}, {'old': old}, 'file:///test') is None
assert gate({'old', 'new'}, {'old'}, {'old': old, 'new': {'kFrameUrl': 'file:///test'}}, 'file:///test') is None
new = dict(old, kVideoDecoderName='FFmpegVideoDecoder', kIsPlatformVideoDecoder='false')
assert gate({'old', 'new'}, {'old'}, {'old': old, 'new': new}, 'file:///test') == {'new': new}
try:
    gate({'old', 'new'}, set(), {'old': old, 'new': new}, 'file:///test')
except AssertionError:
    pass
else:
    raise AssertionError('Multiple unexpected current players accepted')
result = {'syntax': 'pass', 'epoch_regressions': '4 passed',
    'sha256': hashes, 'clip_sha256': hashlib.sha256(clip.read_bytes()).hexdigest(),
    'probe': json.loads(probe), 'hardware_access': False}
with (root / 'lifecycle-prepared-02.json').open('x') as f:
    json.dump(result, f, indent=2); f.write('\n')
print(json.dumps(result, indent=2))
