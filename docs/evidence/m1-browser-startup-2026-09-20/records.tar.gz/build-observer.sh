#!/bin/bash
set -eu
cd <HOME>/src/m1-browser-startup-artifacts-20260920
gcc -Wall -Wextra -Werror -O2 -fPIC -shared -o display-observe.so display-observe.c -Wl,--no-as-needed -ldrm -ldl
gcc -Wall -Wextra -Werror -O2 -I/usr/include/libdrm -o observer-check observer-check.c -ldrm
./observer-check > observer-check-plain.txt
LD_PRELOAD="$PWD/display-observe.so" ./observer-check > observer-check-observed.txt 2>observer-check.log
cmp observer-check-plain.txt observer-check-observed.txt
python3 -c "import ast,pathlib; ast.parse(pathlib.Path('display-diagnostic.py').read_text())"
sha256sum display-observe.c display-observe.so display-diagnostic.py playback.py > final-runner-hashes.txt
