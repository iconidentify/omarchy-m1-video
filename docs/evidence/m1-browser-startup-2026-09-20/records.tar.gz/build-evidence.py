from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('<HOME>/src/m1-browser-startup-artifacts-20260920')
dest=Path('<HOME>/src/video-m1-browser-startup-20260920/docs/evidence/m1-browser-startup-2026-09-20')
rows=['chrome-default','chromium-default','chrome-cache-off','chrome-no-cache-object','playback-software','playback-software-v2','playback-installed','display-diagnostic']
files={}
for name in ['identity.json','final-state.json','startup.py','startup.source.sha256','playback.py','playback-attempt1.py','playback.source.sha256','prepare-playback.py','display-observe.c','display-diagnostic.py','build-observer.sh','observer-check.c','observer-check-plain.txt','observer-check-observed.txt','observer-check.log','final-runner-hashes.txt','build-evidence.py','LICENSE-display-observe.txt']:
 files[name]=root/name
for row in rows:
 for suffix in ['.guard.jsonl','.console.log','.env.json']:
  p=root/(row+suffix)
  if p.exists():files[p.name]=p
 for p in (root/row).iterdir():
  if p.is_file() and p.suffix in ('.json','.jsonl','.log','.png','.html'):files[str(p.relative_to(root))]=p
for p in (root/'source').iterdir():
 if p.name not in ['mesa-disk-cache.c','fetch.json']:files[str(p.relative_to(root))]=p
files['fixtures/h264-12s-tagged.mp4']=Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')
records={};manifest={}
for name,p in sorted(files.items()):
 raw=p.read_bytes();data=raw;operation=[]
 if p.suffix not in ('.png','.mp4'):
  s=raw.decode()
  if p.name=='chrome.log':
   tokens=('libva','vaapi','VA display','InitializeSandbox','seccomp-bpf','GPU process exited','DISPLAY_OBSERVE','EGL','OpenGL','gpu_init','gpu_sandbox')
   s='\n'.join(line for line in s.splitlines() if any(t in line for t in tokens))+'\n';operation.append('keep only relevant GPU/VA/sandbox/observer log lines')
  s=s.replace('<HOME>','<HOME>');data=s.encode()
  if '<HOME>' in raw.decode():operation.append('<HOME> -> <HOME>')
 records[name]=data
 manifest[name]={'original_sha256':hashlib.sha256(raw).hexdigest(),'published_sha256':hashlib.sha256(data).hexdigest(),'transform':operation}
out=dest/'records.tar.gz'
with out.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in records.items():
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
(dest/'manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'redaction':'Textual home paths redacted. Browser logs retain only relevant GPU/VA/sandbox/observer lines. Profiles, cores, private crash diagnostics, unrelated issue snapshots and binaries omitted. Original and published hashes retained.','members':manifest},indent=2)+'\n')
print(len(records),'records;',out.stat().st_size,'archive bytes')
