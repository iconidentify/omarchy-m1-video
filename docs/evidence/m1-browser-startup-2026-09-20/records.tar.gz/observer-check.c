#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <sys/stat.h>
#include <xf86drm.h>
int main(void) { struct stat64 s; errno=0; int r=stat64("/sys/dev/char/1:3/device/drm", &s); int e=errno; printf("stat64 %d %d\n", r,e); if(r!=-1||e!=ENOENT)return 1; errno=0; r=drmGetNodeTypeFromFd(-1); e=errno; printf("node %d %d\n",r,e); return r!=-1||e!=EBADF; }
