from pathlib import Path
r=Path('<HOME>/src/m1-browser-startup-artifacts-20260920')
s=Path('<HOME>/src/m1-client-delivery-artifacts-20260920/chrome-row.py').read_text()
s=s.replace('import base64,hashlib,json,os,signal,subprocess,sys,time,urllib.request','import base64,hashlib,json,os,signal,struct,subprocess,sys,time,urllib.request')
s=s.replace("clip=Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s.mp4')","clip=Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')\nmedia_properties={};media_errors=[]")
s=s.replace("def record(kind,**data):\n",'''def record(kind,**data):
 if kind=='media':
  m=data['message'];params=m['params']
  if m['method']=='Media.playerPropertiesChanged':media_properties.setdefault(params['playerId'],{}).update({x['name']:x['value'] for x in params['properties']})
  if m['method']=='Media.playerErrorsRaised':media_errors.extend(params.get('errors',[]))
''')
s=s.replace("record('process_snapshot',label=label,holders=[vars(h) if hasattr(h,'__dict__') else h for h in holders],mapped_drivers=mapped)","record('process_snapshot',label=label,holders=[vars(h) if hasattr(h,'__dict__') else h for h in holders],mapped_drivers=mapped)\n return holders,mapped")
anchor="cmd=['/opt/google/chrome/chrome'"
functions='''def isolation(label):
 info=browser.call('SystemInfo.getInfo');gpu=info['gpu'];record('gpu',label=label,value=info)
 assert gpu['auxAttributes']['sandboxed'] is True
 assert 'AGX' in gpu['auxAttributes']['glRenderer']
 assert gpu['auxAttributes']['processCrashCount']==0
 assert gpu['featureStatus']['opengl'].startswith('enabled') and gpu['featureStatus']['gpu_compositing']=='enabled'
 statuses=[]
 for pid in process_tree(proc.pid):
  try:args=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\\0')
  except (PermissionError,FileNotFoundError):continue
  kind=next((v.decode() for v in args if v in (b'--type=gpu-process',b'--type=renderer')),None)
  if kind:
   tasks=[]
   for task in Path(f'/proc/{pid}/task').iterdir():
    try:text=task.joinpath('status').read_text()
    except FileNotFoundError:continue
    fields={k:v.strip() for k,v in (line.split(':',1) for line in text.splitlines() if ':' in line) if k in ('Name','Pid','Seccomp','Seccomp_filters')};tasks.append(fields)
   statuses.append({'pid':pid,'type':kind,'tasks':tasks})
 record('isolation',label=label,processes=statuses)
 assert all(any(p['type']==kind for p in statuses) for kind in ('--type=gpu-process','--type=renderer'))
 assert all(p['tasks'] and all(t['Seccomp']=='2' for t in p['tasks']) for p in statuses)
def selected(label):
 end=time.monotonic()+5
 while not media_properties and time.monotonic()<end:time.sleep(.1);cdp.evaluate('true')
 props=list(media_properties.values());record('decoder_gate',label=label,players=media_properties)
 assert props and all('kVideoDecoderName' in p for p in props),props
 if mode=='software':assert all(p['kVideoDecoderName']=='FFmpegVideoDecoder' and p['kIsPlatformVideoDecoder']=='false' for p in props),props
 else:
  assert all(p['kVideoDecoderName']=='VaapiVideoDecoder' and p['kIsPlatformVideoDecoder']=='true' for p in props),props
  holders,mapped=snapshot(label);assert holders,'no owned AVD holders'
  expected=str((Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').resolve())
  assert any(expected in paths for paths in mapped.values()),mapped
 assert not media_errors,media_errors
def capture(name):
 display=cdp.evaluate('({dpr:devicePixelRatio,rect:{width:v.getBoundingClientRect().width,height:v.getBoundingClientRect().height},time:v.currentTime})')
 assert display['rect']=={'width':640,'height':360}
 shot=cdp.call('Page.captureScreenshot',{'format':'png','fromSurface':True,'clip':{'x':0,'y':0,'width':640,'height':360,'scale':1}})
 picture=base64.b64decode(shot['data']);size=struct.unpack('>II',picture[16:24]);assert size==(round(640*display['dpr']),round(360*display['dpr']))
 (out/(name+'.png')).write_bytes(picture);record('capture',name=name,display=display,dimensions=size,sha256=hashlib.sha256(picture).hexdigest())
'''
s=s.replace(anchor,functions+anchor)
s=s.replace("record('identity',mode=mode,argv=cmd,", "record('identity',mode=mode,argv=cmd,environment={k:os.environ.get(k) for k in ('MESA_DISK_CACHE_MULTI_FILE','MESA_DISK_CACHE_DATABASE','MESA_DISK_CACHE_SINGLE_FILE','MESA_SHADER_CACHE_DISABLE')},")
s=s.replace("record('loaded',value=cdp.evaluate('load()'))", "isolation('before_media')\n record('loaded',value=cdp.evaluate('load()'));selected('loaded')")
a=s.index("  if index<4:\n")
b=s.index(" snapshot('after_seeks')",a)
s=s[:a]+"  if index<4:capture('seek-'+str(t))\n"+s[b:]
a=s.index(" shot=cdp.call('Page.captureScreenshot'",s.index(" snapshot('survivor')"))
b=s.index(" record('completed'",a)
s=s[:a]+" capture('reopen-1');selected('final');isolation('final')\n"+s[b:]
(r/'playback.py').write_text(s)
