import json,os,subprocess,sys,time,urllib.request
from pathlib import Path
sys.path.insert(0,"<HOME>/src/avd-lab")
from avdlab.chromegpu import WebSocket
from avdlab.chromeplay import process_tree
assert os.environ.get("LIBVA_HW_GUARD_LEASE")
binary=sys.argv[1];out=Path(sys.argv[2]);out.mkdir();profile=out/"profile"
class C:
 def __init__(self,url):self.w=WebSocket(url,timeout=10);self.n=0
 def call(self,name,params=None):
  self.n+=1;self.w.send(json.dumps({"id":self.n,"method":name,"params":params or {}}))
  while True:
   r=json.loads(self.w.recv())
   if r.get("id")==self.n:
    assert "error" not in r,r
    return r["result"]
cmd=[binary,f"--user-data-dir={profile}","--no-first-run","--no-default-browser-check","--disable-extensions","--disable-background-networking","--ozone-platform=wayland","--remote-debugging-port=0","--enable-logging=stderr","--v=0","--app=about:blank"]
cmd.extend(sys.argv[3:])
log=(out/"chrome.log").open("w");proc=subprocess.Popen(cmd,stdout=log,stderr=log)
try:
 end=time.monotonic()+20
 while not (profile/"DevToolsActivePort").exists():
  assert time.monotonic()<end and proc.poll() is None
  time.sleep(.1)
 port=(profile/"DevToolsActivePort").read_text().splitlines()[0]
 def get(name):
  with urllib.request.urlopen("http://127.0.0.1:"+port+name,timeout=3) as r:return json.load(r)
 browser=C(get("/json/version")["webSocketDebuggerUrl"])
 tabs=get("/json/list");tab=C(next(t for t in tabs if t["type"]=="page")["webSocketDebuggerUrl"])
 time.sleep(2)
 info=browser.call("SystemInfo.getInfo");page=tab.call("Runtime.evaluate",{"expression":"JSON.stringify({text:document.body.innerText,dpr:devicePixelRatio,width:innerWidth,height:innerHeight})","returnByValue":True})
 processes=[]
 for pid in process_tree(proc.pid):
  try:
   status=Path(f"/proc/{pid}/status").read_text();args=Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0",b" ").decode()
  except (PermissionError,FileNotFoundError):continue
  fields={k:v.strip() for k,v in (x.split(":",1) for x in status.splitlines() if ":" in x) if k in ["Name","Pid","PPid","NoNewPrivs","Seccomp","Seccomp_filters"]}
  fields["type"]=next((s for s in args.split() if s.startswith("--type=")),"browser");fields["sandbox_switches"]=[s for s in args.split() if "sandbox" in s];fields["threads"]=[]
  for task in Path(f"/proc/{pid}/task").iterdir():
   try:ts=task.joinpath("status").read_text()
   except (PermissionError,FileNotFoundError):continue
   fields["threads"].append({k:v.strip() for k,v in (x.split(":",1) for x in ts.splitlines() if ":" in x) if k in ["Name","Pid","Seccomp","Seccomp_filters"]})
  if fields["type"]=="--type=gpu-process":
   result=subprocess.run(["sudo","-n","cat",f"/proc/{pid}/maps"],capture_output=True,text=True,timeout=3)
   fields["mapped_graphics"]=sorted({x.split()[-1] for x in result.stdout.splitlines() if any(k in x for k in ["libEGL","libGL","libgallium","_dri.so","_drv_video.so"])})
  processes.append(fields)
 (out/"result.json").write_text(json.dumps({"argv":cmd,"browser":get("/json/version"),"gpu":info,"sandbox_page":page,"processes":processes},indent=2)+"\n")
 print(json.dumps({"binary":binary,"gpu_sandboxed":info["gpu"]["auxAttributes"].get("sandboxed"),"renderer":info["gpu"]["auxAttributes"].get("glRenderer"),"features":info["gpu"]["featureStatus"],"decode_profiles":len(info["gpu"].get("videoDecoding",[]))}))
finally:
 try:browser.call("Browser.close")
 except Exception:pass
 try:proc.wait(timeout=5)
 except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=3)
