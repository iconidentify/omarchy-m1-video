/* SPDX-License-Identifier: MIT
 * Dated diagnostic only: preserve the actual return value and errno.
 * No permissions, device requests, mappings or API lifetime changes.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int (*real_stat64)(const char *, struct stat64 *);
static int (*real_node_type)(int);

__attribute__((constructor)) static void resolve(void)
{
    real_stat64 = dlsym(RTLD_NEXT, "stat64");
    real_node_type = dlsym(RTLD_NEXT, "drmGetNodeTypeFromFd");
    if (!real_stat64 || !real_node_type) {
        fputs("DISPLAY_OBSERVE unresolved forwarding symbol\n", stderr);
        _exit(125);
    }
}

int stat64(const char *path, struct stat64 *buf)
{
    int ret = real_stat64(path, buf);
    int saved = errno;
    if (strncmp(path, "/sys/dev/char/", 14) == 0)
        fprintf(stderr, "DISPLAY_OBSERVE pid=%ld stat64 path=%s ret=%d errno=%d\n",
                (long)getpid(), path, ret, saved);
    errno = saved;
    return ret;
}

int drmGetNodeTypeFromFd(int fd)
{
    int ret = real_node_type(fd);
    int saved = errno;
    fprintf(stderr, "DISPLAY_OBSERVE pid=%ld drmGetNodeTypeFromFd fd=%d ret=%d errno=%d\n",
            (long)getpid(), fd, ret, saved);
    errno = saved;
    return ret;
}
