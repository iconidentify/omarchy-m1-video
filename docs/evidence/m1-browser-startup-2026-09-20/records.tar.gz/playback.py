#!/usr/bin/env python3
"""Dated client experiment. Run only within the pinned portable hardware guard."""
import base64,hashlib,json,os,signal,struct,subprocess,sys,time,urllib.request
from pathlib import Path
sys.path.insert(0,'<HOME>/src/avd-lab')
sys.path.insert(0,'<HOME>/src/driver-m1-candidate-20260920/tests')
from avdlab.chromegpu import WebSocket
from avdlab.chromeplay import process_tree
from hwguard import LinuxBackend
assert os.environ.get('LIBVA_HW_GUARD_LEASE')
mode,outdir=sys.argv[1:];out=Path(outdir);out.mkdir()
profile=out/'profile';profile.mkdir();events=(out/'events.jsonl').open('x');proc=None
clip=Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')
media_properties={};media_errors=[]
page=out/'page.html'
page.write_text('''<!doctype html><meta charset="utf-8"><title>M1 delivery playback check</title>
<style>html,body{margin:0;background:#171717}video{width:640px;height:360px;display:inline-block;vertical-align:top}</style><video id="v" muted playsinline preload="auto"></video>
<script>
const v=document.getElementById('v');
const timeout=(p)=>Promise.race([p,new Promise((_,r)=>setTimeout(()=>r(Error('client operation deadline')),8000))]);
const event=(el,name)=>new Promise((resolve,reject)=>{el.addEventListener(name,resolve,{once:true});el.addEventListener('error',()=>reject(Error('media error '+el.error?.code)),{once:true});});
const raf=()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
const quality=()=>{let q=v.getVideoPlaybackQuality();return {total:q.totalVideoFrames,dropped:q.droppedVideoFrames,time:v.currentTime,error:v.error?.code||null,width:v.videoWidth,height:v.videoHeight}};
async function load(){let p=event(v,'loadeddata');v.src=CLIP;v.load();await timeout(p);return quality()}
async function seek(t){v.pause();const frame=new Promise(r=>v.requestVideoFrameCallback((now,m)=>r({mediaTime:m.mediaTime,presentedFrames:m.presentedFrames,width:m.width,height:m.height})));const done=event(v,'seeked');v.currentTime=t;await timeout(done);const f=await timeout(frame);await raf();return {...quality(),frame:f}}
async function playAll(){await seek(0);let before=quality();let done=event(v,'ended');await v.play();await Promise.race([done,new Promise((_,r)=>setTimeout(()=>r(Error('playback deadline')),18000))]);return {before,after:quality()}}
async function two(){await seek(1);let b=document.createElement('video');b.muted=true;b.playsInline=true;b.id='secondary';document.body.appendChild(b);let ready=event(b,'loadeddata');b.src=CLIP;b.load();await timeout(ready);await Promise.all([v.play(),b.play()]);await new Promise(r=>setTimeout(r,1000));return {primary:quality(),secondary:{time:b.currentTime,error:b.error?.code||null,width:b.videoWidth,height:b.videoHeight}}}
async function removeSecond(){let b=document.getElementById('secondary');b.pause();b.removeAttribute('src');b.load();b.remove();let before=quality();await new Promise(r=>setTimeout(r,1000));v.pause();return {before,after:quality()}}
async function reopen(){v.pause();v.removeAttribute('src');v.load();await load();return seek(1)}
</script>'''.replace('CLIP',json.dumps(clip.as_uri())))
def record(kind,**data):
 if kind=='media':
  m=data['message'];params=m['params']
  if m['method']=='Media.playerPropertiesChanged':media_properties.setdefault(params['playerId'],{}).update({x['name']:x['value'] for x in params['properties']})
  if m['method']=='Media.playerErrorsRaised':media_errors.extend(params.get('errors',[]))
 events.write(json.dumps({'kind':kind,**data})+'\n');events.flush();os.fsync(events.fileno())
class CDP:
 def __init__(self,url):self.ws=WebSocket(url,timeout=25);self.n=0
 def call(self,method,params=None):
  self.n+=1;self.ws.send(json.dumps({'id':self.n,'method':method,'params':params or {}}));deadline=time.monotonic()+25
  while time.monotonic()<deadline:
   self.ws.sock.settimeout(max(.1,deadline-time.monotonic()));m=json.loads(self.ws.recv())
   if m.get('method','').startswith('Media.'):record('media',message=m)
   if m.get('id')==self.n:
    if 'error' in m:raise RuntimeError((method,m['error']))
    return m['result']
  raise TimeoutError(method)
 def evaluate(self,code):
  r=self.call('Runtime.evaluate',{'expression':code,'awaitPromise':True,'returnByValue':True})
  if r.get('exceptionDetails'):raise RuntimeError(r['exceptionDetails'])
  return r['result'].get('value')
def snapshot(label):
 tree=process_tree(proc.pid);state=LinuxBackend().state();holders=[h for h in state.holders if h.pid in tree] if state.holders and hasattr(state.holders[0],'pid') else [h for h in state.holders if h['pid'] in tree]
 mapped={}
 for pid in tree:
  try:maps=Path(f'/proc/{pid}/maps').read_text()
  except (PermissionError,FileNotFoundError):
   r=subprocess.run(['sudo','-n','cat',f'/proc/{pid}/maps'],capture_output=True,text=True,timeout=2);maps=r.stdout if r.returncode==0 else ''
  paths=sorted({s.split()[-1] for s in maps.splitlines() if '_drv_video.so' in s})
  if paths:mapped[str(pid)]=paths
 record('process_snapshot',label=label,holders=[vars(h) if hasattr(h,'__dict__') else h for h in holders],mapped_drivers=mapped)
 return holders,mapped
def isolation(label):
 info=browser.call('SystemInfo.getInfo');gpu=info['gpu'];record('gpu',label=label,value=info)
 assert gpu['auxAttributes']['sandboxed'] is True
 assert 'AGX' in gpu['auxAttributes']['glRenderer']
 assert gpu['auxAttributes']['processCrashCount']==0
 assert gpu['featureStatus']['opengl'].startswith('enabled') and gpu['featureStatus']['gpu_compositing']=='enabled'
 statuses=[]
 for pid in process_tree(proc.pid):
  try:args=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').split()
  except (PermissionError,FileNotFoundError):continue
  kind=next((v.decode() for v in args if v in (b'--type=gpu-process',b'--type=renderer')),None)
  if kind:
   tasks=[]
   for task in Path(f'/proc/{pid}/task').iterdir():
    try:text=task.joinpath('status').read_text()
    except FileNotFoundError:continue
    fields={k:v.strip() for k,v in (line.split(':',1) for line in text.splitlines() if ':' in line) if k in ('Name','Pid','Seccomp','Seccomp_filters')};tasks.append(fields)
   statuses.append({'pid':pid,'type':kind,'tasks':tasks})
 record('isolation',label=label,processes=statuses)
 assert all(any(p['type']==kind for p in statuses) for kind in ('--type=gpu-process','--type=renderer'))
 assert all(p['tasks'] and all(t['Seccomp']=='2' for t in p['tasks']) for p in statuses)
def selected(label):
 end=time.monotonic()+5
 while not media_properties and time.monotonic()<end:time.sleep(.1);cdp.evaluate('true')
 props=list(media_properties.values());record('decoder_gate',label=label,players=media_properties)
 assert props and all('kVideoDecoderName' in p for p in props),props
 if mode=='software':assert all(p['kVideoDecoderName']=='FFmpegVideoDecoder' and p['kIsPlatformVideoDecoder']=='false' for p in props),props
 else:
  assert all(p['kVideoDecoderName']=='VaapiVideoDecoder' and p['kIsPlatformVideoDecoder']=='true' for p in props),props
  holders,mapped=snapshot(label);assert holders,'no owned AVD holders'
  expected=str((Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').resolve())
  assert any(expected in paths for paths in mapped.values()),mapped
 assert not media_errors,media_errors
def capture(name):
 display=cdp.evaluate('({dpr:devicePixelRatio,rect:{width:v.getBoundingClientRect().width,height:v.getBoundingClientRect().height},time:v.currentTime})')
 assert display['rect']=={'width':640,'height':360}
 shot=cdp.call('Page.captureScreenshot',{'format':'png','fromSurface':True,'clip':{'x':0,'y':0,'width':640,'height':360,'scale':1}})
 picture=base64.b64decode(shot['data']);size=struct.unpack('>II',picture[16:24]);assert size==(round(640*display['dpr']),round(360*display['dpr']))
 (out/(name+'.png')).write_bytes(picture);record('capture',name=name,display=display,dimensions=size,sha256=hashlib.sha256(picture).hexdigest())
cmd=['/opt/google/chrome/chrome',f'--user-data-dir={profile}','--no-first-run','--no-default-browser-check','--disable-extensions','--disable-background-networking','--ozone-platform=wayland','--remote-debugging-port=0','--force-device-scale-factor=1','--autoplay-policy=no-user-gesture-required','--enable-logging=stderr','--v=0','--app=about:blank','--window-size=1280,720']
if mode=='software':cmd.append('--disable-accelerated-video-decode')
record('identity',mode=mode,argv=cmd,environment={k:os.environ.get(k) for k in ('MESA_DISK_CACHE_MULTI_FILE','MESA_DISK_CACHE_DATABASE','MESA_DISK_CACHE_SINGLE_FILE','MESA_SHADER_CACHE_DISABLE')},clip_sha256=hashlib.sha256(clip.read_bytes()).hexdigest(),driver_path=os.environ.get('LIBVA_DRIVERS_PATH'),driver_sha256=hashlib.sha256((Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').read_bytes()).hexdigest(),lease=os.environ['LIBVA_HW_GUARD_LEASE'])
try:
 with (out/'chrome.log').open('x') as log:proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 end=time.monotonic()+20
 while not (profile/'DevToolsActivePort').exists():
  if proc.poll() is not None or time.monotonic()>end:raise RuntimeError('Chrome did not start')
  time.sleep(.1)
 port=(profile/'DevToolsActivePort').read_text().splitlines()[0]
 def get(path):
  with urllib.request.urlopen('http://127.0.0.1:'+port+path,timeout=3) as r:return json.load(r)
 browser=CDP(get('/json/version')['webSocketDebuggerUrl']);record('system_info',value=browser.call('SystemInfo.getInfo'))
 tabs=get('/json/list');target=next(x for x in tabs if x['type']=='page');cdp=CDP(target['webSocketDebuggerUrl'])
 cdp.call('Media.enable');cdp.call('Page.enable');cdp.call('Page.navigate',{'url':page.as_uri()})
 end=time.monotonic()+10
 while cdp.evaluate('typeof load')!='function':
  if time.monotonic()>end:raise RuntimeError('page not ready')
  time.sleep(.1)
 isolation('before_media')
 record('loaded',value=cdp.evaluate('load()'));selected('loaded')
 for index,t in enumerate([1,4,2,6]*5):
  state=cdp.evaluate(f'seek({t})');record('seek',index=index,target=t,value=state)
  assert abs(state['time']-t)<.002 and abs(state['frame']['mediaTime']-t)<.002 and not state['error']
  if index<4:capture('seek-'+str(t))
 snapshot('after_seeks');play=cdp.evaluate('playAll()');record('play_all',value=play)
 assert play['after']['time']>=11.9 and not play['after']['error']
 assert play['after']['dropped']==play['before']['dropped']
 record('two_videos',value=cdp.evaluate('two()'));snapshot('two_videos')
 state=cdp.evaluate('removeSecond()');record('survivor',value=state);assert state['after']['time']-state['before']['time']>=.5 and not state['after']['error']
 snapshot('survivor');state=cdp.evaluate('reopen()');record('reopen',value=state);assert abs(state['frame']['mediaTime']-1)<.002 and not state['error']
 capture('reopen-1');selected('final');isolation('final')
 record('completed',passed_execution=True)
 print(json.dumps({'row':mode,'execution':'complete','directory':str(out)}))
except BaseException as e:
 record('failure',error=str(e));raise
finally:
 if proc is not None and proc.poll() is None:
  try:
   if 'browser' in globals():browser.call('Browser.close')
  except Exception:pass
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:
   proc.terminate()
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
 events.close()
