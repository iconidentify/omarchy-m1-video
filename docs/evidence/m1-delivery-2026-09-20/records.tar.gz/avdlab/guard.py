"""Safety layer for Apple Video Decoder (AVD) experiments.

Every harness in avd-lab goes through this module. It exists because a bad
apple_avd build can oops the kernel, leave /dev/video0 wedged until reboot, or
hard-reset the machine, and a process stuck in the kernel cannot be killed.

Rules it enforces:
- Inspect the decoder through sysfs and /proc only; never open the device to
  find out whether it is healthy.
- Never wait on a child without a deadline. A child that survives SIGKILL is
  stuck in the kernel: report the decoder as wedged and stop.
- Load kernel modules only with insmod, only with explicit consent, and never
  install anything as the module the system loads at boot.
- Write results with fsync so they survive a hard reset.
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable

OOPS_MARKERS = ("Unable to handle kernel", "Internal error: Oops", "Call trace:", "BUG:", "kernel BUG at")
# Wait channels of tasks blocked inside V4L2 / mem2mem / AVD code.
DECODER_WCHANS = ("video_do_ioctl", "v4l2_", "vb2_", "m2m", "avd_", "media_request")
# Modules apple_avd needs; insmod does not resolve them.
AVD_DEPENDENCIES = ("videodev", "mc", "v4l2-mem2mem", "videobuf2-dma-contig", "v4l2-h264", "v4l2-vp9")


class GuardError(RuntimeError):
    """A safety check failed; the harness must stop."""


@dataclass
class DecoderState:
    module_loaded: bool
    module_taint: str | None
    video_node: str | None
    media_node: str | None
    holders: list[dict] = field(default_factory=list)
    stuck_tasks: list[dict] = field(default_factory=list)

    @property
    def busy(self) -> bool:
        return bool(self.holders)

    @property
    def wedged(self) -> bool:
        return any(t["state"] == "D" for t in self.stuck_tasks)


def _read(path: str | Path) -> str | None:
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def find_avd_nodes() -> tuple[str | None, str | None]:
    """Return (/dev/videoN, /dev/mediaN) of the AVD decoder, from sysfs names only."""
    video = media = None
    for dev in sorted(Path("/sys/class/video4linux").glob("video*")):
        if _read(dev / "name") == "avd":
            video = f"/dev/{dev.name}"
            for m in (dev / "device").glob("media*"):
                media = f"/dev/{m.name}"
    return video, media


def _proc_tasks():
    for pid_dir in Path("/proc").iterdir():
        if pid_dir.name.isdigit():
            for task in (pid_dir / "task").glob("*"):
                yield pid_dir.name, task


def decoder_state() -> DecoderState:
    video, media = find_avd_nodes()
    nodes = {n for n in (video, media) if n}
    holders = []
    if nodes:
        for pid_dir in Path("/proc").iterdir():
            if not pid_dir.name.isdigit():
                continue
            try:
                fds = [os.readlink(fd) for fd in (pid_dir / "fd").iterdir()]
            except OSError:
                continue
            if nodes.intersection(fds):
                cmd = (_read(pid_dir / "cmdline") or "").replace("\0", " ").strip()
                holders.append({"pid": int(pid_dir.name), "cmd": cmd[:160]})
    stuck = []
    for pid, task in _proc_tasks():
        wchan = _read(task / "wchan") or ""
        if not any(w in wchan for w in DECODER_WCHANS):
            continue
        stat = _read(task / "stat") or ""
        state = stat.rsplit(")", 1)[-1].split()[0] if ")" in stat else "?"
        stuck.append({"pid": int(pid), "tid": int(task.name), "state": state,
                      "wchan": wchan, "comm": _read(task / "comm")})
    return DecoderState(
        module_loaded=Path("/sys/module/apple_avd").exists(),
        module_taint=_read("/sys/module/apple_avd/taint"),
        video_node=video,
        media_node=media,
        holders=holders,
        stuck_tasks=stuck,
    )


def boot_time() -> str:
    btime = next(int(l.split()[1]) for l in Path("/proc/stat").read_text().splitlines() if l.startswith("btime"))
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(btime))


def kernel_oopses_since(since: str) -> list[str]:
    """Kernel log lines since `since` (journalctl time spec) that mark an oops or BUG."""
    out = subprocess.run(["journalctl", "-k", "--since", since, "--no-pager", "-o", "short-precise"],
                         capture_output=True, text=True, timeout=30).stdout
    return [l for l in out.splitlines() if any(m in l for m in OOPS_MARKERS)]


def preflight(require_module: bool = True) -> DecoderState:
    """Refuse to start unless the decoder is present, free, and not wedged, and the kernel is clean."""
    st = decoder_state()
    if require_module and not (st.module_loaded and st.video_node):
        raise GuardError("apple_avd is not loaded (or has no video node)")
    if st.wedged:
        raise GuardError(f"decoder wedged: tasks stuck in D state {st.stuck_tasks}")
    if st.busy:
        raise GuardError(f"decoder in use by {st.holders}; close them first")
    oops = kernel_oopses_since(boot_time())
    if oops:
        raise GuardError(f"kernel already oopsed this boot; reboot before testing: {oops[:2]}")
    return st


# A task sleeping in decoder code is normal: avd_submit_job() waits for the firmware
# queue with usleep_range(), which shows as state D with wchan avd_submit_job. A wedged
# task is one that stays in D without being scheduled at all, well past the driver's own
# 2 s watchdog.
WEDGE_GRACE_S = 10.0
_blocked: dict[int, tuple[int | None, float]] = {}


def _context_switches(pid: int, tid: int) -> int | None:
    status = _read(f"/proc/{pid}/task/{tid}/status")
    if status is None:
        return None
    return sum(int(l.split()[1]) for l in status.splitlines()
               if l.startswith(("voluntary_ctxt_switches:", "nonvoluntary_ctxt_switches:")))


def wedge_monitor() -> str | None:
    """abort_if callback for run(): stop when a task has been stuck in decoder code,
    unscheduled, for WEDGE_GRACE_S. Keeps state between calls; poll it regularly."""
    now = time.monotonic()
    seen: dict[int, tuple[int | None, float]] = {}
    wedged = []
    for t in decoder_state().stuck_tasks:
        if t["state"] != "D":
            continue
        switches = _context_switches(t["pid"], t["tid"])
        prev = _blocked.get(t["tid"])
        since = prev[1] if prev and switches is not None and prev[0] == switches else now
        seen[t["tid"]] = (switches, since)
        if now - since >= WEDGE_GRACE_S:
            wedged.append({**t, "blocked_s": round(now - since, 1)})
    _blocked.clear()
    _blocked.update(seen)
    return f"decoder wedged: {wedged}" if wedged else None


@dataclass
class RunResult:
    cmd: list[str]
    returncode: int | None
    seconds: float
    timed_out: bool
    wedged: bool
    stdout: str
    stderr: str
    abort_reason: str | None = None


def _pump_timeline(src, out_file, timeline_path: Path) -> None:
    with open(timeline_path, "w") as timeline:
        for line in src:
            out_file.write(line)
            out_file.flush()
            timeline.write(f"{time.monotonic_ns()}\t{line}")
            timeline.flush()
    out_file.close()


def run(cmd: list[str], deadline: float, env: dict | None = None, log_dir: Path | None = None,
        name: str = "run", cwd: str | Path | None = None, poll: float = 2.0,
        abort_if: Callable[[], str | None] | None = None, timeline: bool = False) -> RunResult:
    """Run a command with a hard deadline. Never blocks indefinitely on a stuck child.

    abort_if is called every `poll` seconds; a non-empty return stops the run early
    (for example wedge_monitor).

    timeline=True (with log_dir) also writes <name>.timeline: every stdout line prefixed
    with the CLOCK_MONOTONIC nanoseconds at which it arrived, the clock of bpftrace's
    nsecs, so output can be lined up with trace events. The child must not buffer stdout.
    """
    started = time.monotonic()
    out_path = err_path = None
    if log_dir:
        log_dir.mkdir(parents=True, exist_ok=True)
        out_path, err_path = log_dir / f"{name}.out", log_dir / f"{name}.err"
    pump = None
    stdout = subprocess.PIPE if (timeline and out_path) or not out_path else open(out_path, "w")
    stderr = open(err_path, "w") if err_path else subprocess.PIPE
    proc = subprocess.Popen(cmd, stdout=stdout, stderr=stderr, text=True, env=env, cwd=cwd,
                            start_new_session=True)
    if timeline and out_path:
        pump = threading.Thread(target=_pump_timeline, daemon=True,
                                args=(proc.stdout, open(out_path, "w"), log_dir / f"{name}.timeline"))
        pump.start()
    timed_out = wedged = False
    abort_reason = None
    end = started + deadline
    while True:
        try:
            proc.wait(timeout=max(0.05, min(poll, end - time.monotonic())))
            break
        except subprocess.TimeoutExpired:
            pass
        if time.monotonic() >= end:
            timed_out = True
        elif abort_if and (abort_reason := abort_if()):
            pass
        else:
            continue
        for sig, grace in ((signal.SIGTERM, 3), (signal.SIGKILL, 5)):
            try:
                os.killpg(proc.pid, sig)
            except ProcessLookupError:
                break
            try:
                proc.wait(timeout=grace)
                break
            except subprocess.TimeoutExpired:
                continue
        else:
            wedged = True  # survived SIGKILL: stuck in the kernel, do not wait
        break
    if out_path:
        if pump:
            pump.join(timeout=5)  # a wedged child may still hold the pipe; the pump is a daemon
        else:
            stdout.close()
        stderr.close()
        o, e = out_path.read_text(errors="replace"), err_path.read_text(errors="replace")
    elif not wedged:
        o, e = proc.communicate(timeout=5)
    else:
        o = e = ""
    return RunResult(cmd, proc.returncode, round(time.monotonic() - started, 3), timed_out, wedged, o, e,
                     abort_reason)


class ResultLog:
    """Append-only JSON-lines log, fsynced after every record."""

    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)

    def write(self, **record):
        record.setdefault("time", time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        line = json.dumps(record, default=lambda o: asdict(o) if hasattr(o, "__dataclass_fields__") else str(o))
        os.write(self._fd, (line + "\n").encode())
        os.fsync(self._fd)


def load_test_module(ko: Path, consent: bool) -> DecoderState:
    """insmod a test build of apple_avd. Requires explicit consent; never touches boot-time modules."""
    if not consent:
        raise GuardError("loading kernel code needs explicit consent (--i-saved-my-work): it can crash the machine")
    ko = ko.resolve()
    if str(ko).startswith("/usr/lib/modules") or str(ko).startswith("/lib/modules"):
        raise GuardError("refusing to load from the system module tree; use a build output path")
    st = decoder_state()
    if st.wedged or st.busy:
        raise GuardError(f"decoder not safe to swap: busy={st.holders} stuck={st.stuck_tasks}")
    subprocess.run(["sudo", "-n", "modprobe", "-a", *AVD_DEPENDENCIES], check=True, timeout=60)
    if st.module_loaded:
        subprocess.run(["sudo", "-n", "rmmod", "apple_avd"], check=True, timeout=60)
    subprocess.run(["sudo", "-n", "insmod", str(ko)], check=True, timeout=60)
    for _ in range(50):
        new = decoder_state()
        if new.video_node:
            return new
        time.sleep(0.1)
    raise GuardError("module loaded but no AVD video node appeared")


def unload_module() -> None:
    st = decoder_state()
    if not st.module_loaded:
        return
    if st.wedged or st.busy:
        raise GuardError(f"not unloading a busy or wedged decoder: busy={st.holders} stuck={st.stuck_tasks}")
    subprocess.run(["sudo", "-n", "rmmod", "apple_avd"], check=True, timeout=60)
