"""Check what a player actually shows, not only what the decoder produces.

Conformance checksums the decoded pictures; they say nothing about the path from
the decoder's dma-buf to the screen, where mpv's Vulkan renderer once showed a
green/pink ghost picture over correct frames. For each renderer configuration this
plays a clip in mpv, takes a screenshot of the rendered window (which goes through
the same hardware-frame import as playback) over mpv's IPC socket, and compares it
with a software-decoded screenshot of the same frame by PSNR. It also records which
hardware decoder mpv really used and how many frames it dropped while playing.

Opens short-lived mpv windows on the current Wayland session and uses the decoder,
so run it alone.

    python3 -m avdlab.playback ~/Downloads/sample-30s.mp4
    python3 -m avdlab.playback clip.mp4 --config gpu-next:opengl:vaapi --config gpu-next:vulkan:vaapi
"""

from __future__ import annotations

import argparse
import json
import os
import re
import socket
import subprocess
import time
from pathlib import Path

from avdlab.guard import ResultLog

LAB = Path(__file__).resolve().parent.parent
DEFAULT_CONFIGS = ("gpu-next:opengl:vaapi", "gpu-next:vulkan:vaapi", "gpu:opengl:vaapi", "gpu-next:opengl:vaapi-copy")


class Mpv:
    """An mpv process driven over its JSON IPC socket."""

    def __init__(self, clip: Path, vo: str, gpu_api: str, hwdec: str, start: float, work: Path, name: str):
        self.sock_path = work / f"{name}.sock"
        self.log_path = work / f"{name}.log"
        self.sock_path.unlink(missing_ok=True)
        cmd = ["mpv", "--no-config", "--no-audio", "--pause", "--keep-open=yes", "--osd-level=0",
               "--really-quiet", f"--start={start}", f"--vo={vo}", f"--gpu-api={gpu_api}",
               f"--hwdec={hwdec}", f"--input-ipc-server={self.sock_path}", f"--log-file={self.log_path}",
               "--title=avdlab-playback", str(clip)]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.sock = None
        self._buf = b""
        self._id = 0

    def connect(self, timeout: float = 15.0) -> None:
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if self.proc.poll() is not None:
                raise RuntimeError(f"mpv exited ({self.proc.returncode}); see {self.log_path}")
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(str(self.sock_path))
                s.settimeout(10)
                self.sock = s
                return
            except OSError:
                time.sleep(0.1)
        raise RuntimeError("mpv IPC socket did not come up")

    def command(self, *args):
        self._id += 1
        request_id = self._id
        self.sock.sendall((json.dumps({"command": list(args), "request_id": request_id}) + "\n").encode())
        while True:
            while b"\n" not in self._buf:
                chunk = self.sock.recv(65536)
                if not chunk:
                    raise RuntimeError("mpv closed the IPC socket")
                self._buf += chunk
            line, self._buf = self._buf.split(b"\n", 1)
            msg = json.loads(line)
            if msg.get("request_id") == request_id:
                if msg.get("error") not in ("success", None):
                    raise RuntimeError(f"mpv {args[0]}: {msg['error']}")
                return msg.get("data")

    def wait_property(self, name: str, predicate, timeout: float = 15.0):
        end = time.monotonic() + timeout
        value = None
        while time.monotonic() < end:
            try:
                value = self.command("get_property", name)
            except RuntimeError:
                value = None
            if predicate(value):
                return value
            time.sleep(0.1)
        return value

    def quit(self) -> None:
        try:
            if self.sock:
                self.command("quit")
        except (RuntimeError, OSError):
            pass
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait(timeout=5)


def psnr(a: Path, b: Path) -> float | None:
    """PSNR in dB between two screenshots; scales b to a's size if they differ."""
    out = subprocess.run(["ffmpeg", "-hide_banner", "-nostdin", "-i", str(a), "-i", str(b), "-lavfi",
                          "[1:v][0:v]scale2ref[b][a];[a][b]psnr", "-f", "null", "-"],
                         capture_output=True, text=True, timeout=60).stderr
    m = re.search(r"average:(inf|[0-9.]+)", out)
    if not m:
        return None
    return float("inf") if m.group(1) == "inf" else float(m.group(1))


def screenshot(clip: Path, vo: str, gpu_api: str, hwdec: str, start: float, work: Path, name: str,
               play_seconds: float) -> dict:
    mpv = Mpv(clip, vo, gpu_api, hwdec, start, work, name)
    result: dict = {"vo": vo, "gpu_api": gpu_api, "hwdec": hwdec}
    try:
        mpv.connect()
        mpv.wait_property("time-pos", lambda v: v is not None and v >= start - 0.5)
        time.sleep(0.5)  # let the paused frame render
        shot = work / f"{name}.png"
        mpv.command("screenshot-to-file", str(shot), "window")
        result["screenshot"] = str(shot)
        result["hwdec_current"] = mpv.command("get_property", "hwdec-current")
        if play_seconds > 0:
            mpv.command("set_property", "pause", False)
            time.sleep(play_seconds)
            result["frame_drops"] = mpv.command("get_property", "frame-drop-count")
            result["decoder_drops"] = mpv.command("get_property", "decoder-frame-drop-count")
            result["played_to"] = mpv.command("get_property", "time-pos")
    except RuntimeError as e:
        result["error"] = str(e)
    finally:
        mpv.quit()
    log = mpv.log_path.read_text(errors="replace") if mpv.log_path.exists() else ""
    result["hw_line"] = next((l.strip() for l in log.splitlines() if "Using hardware decoding" in l), None)
    result["errors"] = [l.strip()[:200] for l in log.splitlines() if re.search(r"\[e\]|failed", l)][:5]
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("clip", type=Path)
    ap.add_argument("--config", action="append", help="vo:gpu-api:hwdec (repeatable)")
    ap.add_argument("--start", type=float, default=5.0, help="seek to this time before the screenshot")
    ap.add_argument("--play", type=float, default=10.0, help="seconds of playback to count dropped frames")
    ap.add_argument("--min-psnr", type=float, default=40.0, help="below this a configuration fails")
    args = ap.parse_args()

    if not os.environ.get("WAYLAND_DISPLAY"):
        raise SystemExit("needs a Wayland session (WAYLAND_DISPLAY)")
    run_dir = LAB / "results" / time.strftime("playback-%Y%m%d-%H%M%S")
    run_dir.mkdir(parents=True)
    log = ResultLog(run_dir / "results.jsonl")
    clip = args.clip.expanduser().resolve()

    reference = screenshot(clip, "gpu-next", "opengl", "no", args.start, run_dir, "software", 0)
    log.write(event="reference", **reference)
    if "error" in reference:
        print(f"software reference failed: {reference['error']}")
        return 2

    failed = 0
    for config in args.config or DEFAULT_CONFIGS:
        vo, gpu_api, hwdec = config.split(":")
        name = config.replace(":", "_")
        r = screenshot(clip, vo, gpu_api, hwdec, args.start, run_dir, name, args.play)
        if "screenshot" in r and Path(r["screenshot"]).exists():
            r["psnr_db"] = psnr(Path(reference["screenshot"]), Path(r["screenshot"]))
        hardware = bool(r.get("hwdec_current")) and r.get("hwdec_current") != "no"
        ok = "error" not in r and hardware and (r.get("psnr_db") or 0) >= args.min_psnr
        failed += not ok
        r["ok"] = ok
        log.write(event="config", **r)
        print(f"{config:28s} {'OK  ' if ok else 'FAIL'} hwdec={r.get('hwdec_current')} psnr={r.get('psnr_db')} "
              f"drops={r.get('frame_drops')}/{r.get('decoder_drops')} {r.get('error', '')}")
    print(f"results: {run_dir}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
