import hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
root=Path('<HOME>/src/m1-client-delivery-artifacts-20260920')
driver=Path('<HOME>/src/driver-m1-candidate-20260920')
bundle=root/'omarchy-m1-mpv-c1-20260920';bundle.mkdir()
identity=json.loads((root/'identity.json').read_text())
source=identity['candidate_source']
archive=subprocess.check_output(['git','archive',source],cwd=driver)
(bundle/'source').mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(bundle/'source',filter='data')
(bundle/'lib').mkdir();(bundle/'samples').mkdir()
shutil.copy2(identity['files']['candidate_driver']['path'],bundle/'lib/v4l2_request_drv_video.so')
shutil.copy2(root/'preview-staging/run-mpv',bundle/'run-mpv')
for src in (root/'fixtures/h264-12s-tagged.mp4',Path('<HOME>/src/m1-delivery-reset-artifacts-20260920/fixtures/vp9-10.webm')):shutil.copy2(src,bundle/'samples'/src.name)
(bundle/'README.md').write_text('''# Experimental M1 mpv demonstration — 2026-09-20

Run `./run-mpv` from this directory for the generated 12-second H.264 clip.
Run `./run-mpv samples/vp9-10.webm` for the short 10-bit VP9 clip.
Run `./run-mpv --check` to validate the bundle and stack without opening video.
Close other hardware video first. Press q or close the player to finish.
The default limit is 30 minutes; `--seconds 30` sets a shorter guard deadline.
A deadline expiry is logged as a timeout, not a successful completion.

This local demonstration contains the exact C1 userspace binary measured on
this M1, plus its complete corresponding source in source/ (including COPYING
and build files). Source: iconidentify/libva-v4l2_request at
5b5046cbda6892f4a63df0015857a80bd42c17cf. All source licences and credits remain.
The launcher is GPL-3.0-or-later. The guard is the unmodified source/tests/hwguard.py.
The generated test clips contain no personal media. No other clips are accepted.

The launcher verifies manifest checksums and the recorded kernel, loaded-module
build-ID note, module file and package versions before starting. The manifest
is an integrity record, not a cryptographic signature or independent attestation.
It selects the included VA driver, OpenGL and VA copy for this process only.
Nothing is installed and no desktop, player or boot setting is changed. Remove
this directory to remove the demo. No root invocation or module reset is needed.
The existing guard may use read-only sudo to inspect decoder holders/journal;
if access or the idle/fault preflight fails, stop and inspect the log.
Logs are under ~/.local/state/omarchy-m1-video/preview (or XDG_STATE_HOME).
Guard source_commit may be null outside a Git checkout; manifest.json binds the
actual source and binary. A build-ID note is not a hash of loaded module memory.

Eight installed/C1 hardware comparison rows passed: H.264 NV12 and VP9 P010,
direct/copy, 160 seeks, 16 reloads and at least 240 seconds of measured playback
with zero drop deltas. All 48 selected rendered-window captures matched their
software reference requirement. Closing a second C1 direct-VA player left its
peer advancing. These are selected generated clips, not all frames or formats.

This is NOT a stable release or qualification for arbitrary personal videos.
Chrome hardware qualification is blocked by GPU sandbox/startup behavior.
Full codec preservation, crop/odd dimensions, format transitions, damaged input,
allocation failure and boot/reset confidence remain open. The earlier desktop
freeze's cause is still unproven. The installed package and its source pin remain
unchanged. Evidence: omarchy-m1-video/docs/evidence/m1-clients-2026-09-20/.
''')
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'driver_source':source,'kernel':identity['kernel'],'module_sha256':identity['files']['module_file']['sha256'],'module_note_sha256':identity['files']['loaded_module_note']['sha256'],'packages':dict(x.split(' ',1) for x in identity['packages'].splitlines() if not x.startswith('google-chrome ')),'sample_sha256':[hashfile(p) for p in sorted((bundle/'samples').iterdir())],'sha256':{str(p.relative_to(bundle)):hashfile(p) for p in sorted(bundle.rglob('*')) if p.is_file()}}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run([str(bundle/'run-mpv'),'--check'],check=True)
# Negative cases stop before guard launch; preserve each measured refusal.
for name,mutate in [('checksum',lambda m:m['sha256'].update({'lib/v4l2_request_drv_video.so':'0'*64})),('version',lambda m:m['packages'].update({'mpv':'not-the-tested-version'}))]:
 changed=json.loads(json.dumps(manifest));mutate(changed);(bundle/'manifest.json').write_text(json.dumps(changed)+'\n')
 try:
  result=subprocess.run([str(bundle/'run-mpv'),'--check'],text=True,capture_output=True)
  (root/('preview-negative-'+name+'.log')).write_text(result.stdout+result.stderr)
  assert result.returncode==2 and ('checksum mismatch' if name=='checksum' else 'version mismatch') in result.stderr,result
 finally:(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(root/(bundle.name+'.tar.gz'),'w:gz') as tar:tar.add(bundle,arcname=bundle.name)
print('Bundle',bundle,'SHA256',hashfile(root/(bundle.name+'.tar.gz')))
