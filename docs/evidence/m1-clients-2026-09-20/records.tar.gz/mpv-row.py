#!/usr/bin/env python3
"""Dated mpv delivery experiment using the existing avdlab IPC client."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'<HOME>/src/avd-lab')
from avdlab.playback import Mpv
assert os.environ.get('LIBVA_HW_GUARD_LEASE')
mode,codec,target=sys.argv[1:];out=Path(target);out.mkdir();log=(out/'events.jsonl').open('x');players=[]
fixtures={'h264':Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4'),'vp9-10':Path('<HOME>/src/m1-delivery-reset-artifacts-20260920/fixtures/vp9-10.webm')}
clip=fixtures[codec];positions=[1.,4.,2.,6.] if codec=='h264' else [0.,12/27,6/27,18/27]
def emit(kind,**data):log.write(json.dumps({'kind':kind,**data})+'\n');log.flush();os.fsync(log.fileno())
def get(p,name):return p.command('get_property',name)
def wait(p,name,predicate):
 end=time.monotonic()+8
 while time.monotonic()<end:
  try:value=get(p,name)
  except RuntimeError:value=None
  if predicate(value):return value
  time.sleep(.03)
 raise RuntimeError('property deadline '+name+' '+str(value))
def position(p,t):
 p.command('set_property','pause',True);p.command('seek',t,'absolute+exact')
 wait(p,'seeking',lambda x:x is False);v=wait(p,'time-pos',lambda x:x is not None and abs(x-t)<.003);time.sleep(.12);return v
def identify(p):
 hw=get(p,'hwdec-current');assert hw==mode if mode!='no' else hw in ('','no',None)
 paths=sorted({s.split()[-1] for s in Path(f'/proc/{p.proc.pid}/maps').read_text().splitlines() if '_drv_video.so' in s})
 if mode!='no':assert str((Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').resolve()) in [str(Path(x).resolve()) for x in paths]
 return {'hwdec':hw,'mapped_drivers':paths,'video_params':get(p,'video-params'),'output_params':get(p,'video-out-params'),'current_vo':get(p,'current-vo')}
def start(path,name):
 p=Mpv(path,'gpu-next','opengl',mode,0,out,name);players.append(p);p.connect(timeout=8);wait(p,'time-pos',lambda x:x is not None);wait(p,'video-out-params',lambda x:isinstance(x,dict));wait(p,'hwdec-current',lambda x:x in ('no','') if mode=='no' else x==mode);emit('player',name=name,identity=identify(p));return p
def capture(p,name):
 file=out/(name+'.png');p.command('screenshot-to-file',str(file),'window');emit('capture',name=name,position=get(p,'time-pos'),sha256=hashlib.sha256(file.read_bytes()).hexdigest())
def drops(p):return {'render':get(p,'frame-drop-count'),'decode':get(p,'decoder-frame-drop-count')}
emit('identity',mode=mode,codec=codec,input_sha256=hashlib.sha256(clip.read_bytes()).hexdigest(),driver_sha256=hashlib.sha256((Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').read_bytes()).hexdigest(),lease=os.environ['LIBVA_HW_GUARD_LEASE'])
try:
 p=start(clip,'player')
 for index,t in enumerate(positions*5):
  actual=position(p,t);emit('seek',index=index,target=t,actual=actual)
  if index<4:capture(p,'seek-'+str(index))
 for index in range(2):
  position(p,positions[1]);p.command('loadfile',str(clip),'replace');wait(p,'time-pos',lambda x:x is not None and abs(x)<.003)
  actual=position(p,positions[0]);emit('reopen',index=index,actual=actual,identity=identify(p));capture(p,'reopen-'+str(index))
 position(p,0);p.command('set_property','loop-file','inf');before=drops(p);p.command('set_property','pause',False);start_time=time.monotonic();samples=[]
 while time.monotonic()-start_time<30:
  time.sleep(.5);state={'elapsed':time.monotonic()-start_time,'position':get(p,'time-pos'),'drops':drops(p)};samples.append(state);emit('play_sample',**state)
 p.command('set_property','pause',True);p.command('set_property','loop-file','no');after=drops(p)
 assert max(s['position'] for s in samples)-min(s['position'] for s in samples)>.3
 assert all(s['drops']==before for s in samples),(before,after)
 emit('play_complete',elapsed=time.monotonic()-start_time,before=before,after=after)
 emit('completed',passed_execution=True);print(json.dumps({'row':str(out),'result':'complete'}))
except BaseException as error:emit('failure',error=str(error));raise
finally:
 for p in reversed(players):p.quit()
 log.close()
