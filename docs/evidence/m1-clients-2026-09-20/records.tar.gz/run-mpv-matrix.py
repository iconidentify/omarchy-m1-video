import hashlib,json,os,re,signal,struct,subprocess,sys
from pathlib import Path
root=Path('<HOME>/src/m1-client-delivery-artifacts-20260920');driver=Path('<HOME>/src/driver-m1-candidate-20260920');active=None
refs={'h264':root/'mpv-software-h264-v2','vp9-10':root/'mpv-software-vp9-10'}
rows=[(label,codec,mode) for label in ['baseline','candidate'] for codec in ['h264','vp9-10'] for mode in ['vaapi','vaapi-copy']]
def stop(signum,frame):
 if active is not None and active.poll() is None:active.terminate();active.wait(timeout=12)
 raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
for label,codec,mode in rows:
 name=f'mpv-{label}-{codec}-{mode}';env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',LIBVA_DRIVER_NAME='v4l2_request',LIBVA_DRIVERS_PATH='/usr/lib/dri' if label=='baseline' else '<HOME>/src/m1-delivery-reset-artifacts-20260920/driver-build/src')
 cmd=['python3',str(driver/'tests/hwguard.py'),'--identity','avd','--deadline','180','--log',str(root/(name+'.guard.jsonl')),'--','python3',str(root/'mpv-row.py'),mode,codec,str(root/name)]
 with (root/(name+'.console.log')).open('x') as log:
  active=subprocess.Popen(cmd,cwd=driver,env=env,stdout=log,stderr=subprocess.STDOUT);rc=active.wait();active=None
 if rc:raise SystemExit(name+' failed; matrix stopped')
 events=[json.loads(x) for x in (root/name/'events.jsonl').read_text().splitlines()];assert events[-1]['kind']=='completed' and sum(x['kind']=='seek' for x in events)==20 and sum(x['kind']=='reopen' for x in events)==2
 guards=[json.loads(x) for x in (root/(name+'.guard.jsonl')).read_text().splitlines()];assert guards[-1]['status']=='ok' and guards[-1]['idle']
 comparisons=[]
 for shot in sorted((root/name).glob('*.png')):
  ref=refs[codec]/shot.name;a=ref.read_bytes();b=shot.read_bytes();assert struct.unpack('>II',a[16:24])==struct.unpack('>II',b[16:24]),shot.name
  if a==b:value='identical'
  else:
   c=['ffmpeg','-nostdin','-hide_banner','-threads','1','-i',str(ref),'-threads','1','-i',str(shot),'-filter_complex_threads','1','-lavfi','psnr','-f','null','-'];r=subprocess.run(c,capture_output=True,text=True,timeout=15);assert r.returncode==0,r.stderr
   (root/name/(shot.stem+'.comparison.log')).write_text(r.stderr);m=re.search(r'average:(inf|[0-9.]+)',r.stderr);assert m,m;value=m[1];assert float(value)>=40,(name,shot.name,value)
  comparisons.append({'capture':shot.name,'psnr':value,'sha256':hashlib.sha256(b).hexdigest(),'reference_sha256':hashlib.sha256(a).hexdigest()})
 assert len(comparisons)==6
 (root/name/'comparison.json').write_text(json.dumps({'passed':True,'comparisons':comparisons},indent=2)+'\n');print(name,'PASS',flush=True)
print('MATRIX COMPLETE',flush=True)
