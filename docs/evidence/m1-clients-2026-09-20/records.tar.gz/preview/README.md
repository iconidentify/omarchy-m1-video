# Experimental M1 mpv demonstration — 2026-09-20

Run `./run-mpv` from this directory for the generated 12-second H.264 clip.
Run `./run-mpv samples/vp9-10.webm` for the short 10-bit VP9 clip.
Run `./run-mpv --check` to validate the bundle and stack without opening video.
Close other hardware video first. Press q or close the player to finish.
The default limit is 30 minutes; `--seconds 30` sets a shorter guard deadline.
A deadline expiry is logged as a timeout, not a successful completion.

This local demonstration contains the exact C1 userspace binary measured on
this M1, plus its complete corresponding source in source/ (including COPYING
and build files). Source: iconidentify/libva-v4l2_request at
5b5046cbda6892f4a63df0015857a80bd42c17cf. All source licences and credits remain.
The launcher is GPL-3.0-or-later. The guard is the unmodified source/tests/hwguard.py.
The generated test clips contain no personal media. No other clips are accepted.

The launcher verifies manifest checksums and the recorded kernel, loaded-module
build-ID note, module file and package versions before starting. The manifest
is an integrity record, not a cryptographic signature or independent attestation.
It selects the included VA driver, OpenGL and VA copy for this process only.
Nothing is installed and no desktop, player or boot setting is changed. Remove
this directory to remove the demo. No root invocation or module reset is needed.
The existing guard may use read-only sudo to inspect decoder holders/journal;
if access or the idle/fault preflight fails, stop and inspect the log.
Logs are under ~/.local/state/omarchy-m1-video/preview (or XDG_STATE_HOME).
Guard source_commit may be null outside a Git checkout; manifest.json binds the
actual source and binary. A build-ID note is not a hash of loaded module memory.

Eight installed/C1 hardware comparison rows passed: H.264 NV12 and VP9 P010,
direct/copy, 160 seeks, 16 reloads and at least 240 seconds of measured playback
with zero drop deltas. All 48 selected rendered-window captures matched their
software reference requirement. Closing a second C1 direct-VA player left its
peer advancing. These are selected generated clips, not all frames or formats.

This is NOT a stable release or qualification for arbitrary personal videos.
Chrome hardware qualification is blocked by GPU sandbox/startup behavior.
Full codec preservation, crop/odd dimensions, format transitions, damaged input,
allocation failure and boot/reset confidence remain open. The earlier desktop
freeze's cause is still unproven. The installed package and its source pin remain
unchanged. Evidence: omarchy-m1-video/docs/evidence/m1-clients-2026-09-20/.
