#!/usr/bin/env python3
"""One dated C1 two-player close/survive measurement; requires hwguard."""
import hashlib,json,os,sys,time
from pathlib import Path
sys.path.insert(0,'<HOME>/src/avd-lab')
from avdlab.playback import Mpv
assert os.environ.get('LIBVA_HW_GUARD_LEASE')
out=Path(sys.argv[1]);out.mkdir();players=[]
clip=Path('<HOME>/src/m1-client-delivery-artifacts-20260920/fixtures/h264-12s-tagged.mp4')
expected=(Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').resolve()
log=(out/'events.jsonl').open('x')
def emit(kind,**data):
 log.write(json.dumps({'kind':kind,**data})+'\n');log.flush();os.fsync(log.fileno())
def get(p,key):return p.command('get_property',key)
def sample(p):return {k:get(p,k) for k in ('time-pos','hwdec-current','frame-drop-count','decoder-frame-drop-count')}
def progress(p):
 before=sample(p);time.sleep(2);after=sample(p)
 assert after['time-pos']>before['time-pos']+1,(before,after)
 assert after['hwdec-current']=='vaapi'
 assert after['frame-drop-count']==before['frame-drop-count'] and after['decoder-frame-drop-count']==before['decoder-frame-drop-count']
 return {'before':before,'after':after}
try:
 emit('identity',driver_sha256=hashlib.sha256(expected.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(clip.read_bytes()).hexdigest(),lease=os.environ['LIBVA_HW_GUARD_LEASE'])
 for name in ('survivor','closing'):
  p=Mpv(clip,'gpu-next','opengl','vaapi',0,out,name);players.append(p);p.connect(timeout=8)
  assert p.wait_property('hwdec-current',lambda v:v=='vaapi',timeout=8)=='vaapi'
  paths=sorted({x.split()[-1] for x in Path(f'/proc/{p.proc.pid}/maps').read_text().splitlines() if '_drv_video.so' in x})
  assert str(expected) in paths
  emit('player',name=name,pid=p.proc.pid,mapped_drivers=paths,state=sample(p))
 for p in players:p.command('set_property','pause',False)
 emit('concurrent',survivor=progress(players[0]),closing=sample(players[1]))
 players[1].quit();assert players[1].proc.poll()==0
 emit('closed',pid=players[1].proc.pid,returncode=players[1].proc.returncode)
 emit('survived',**progress(players[0]))
 emit('completed')
finally:
 for p in reversed(players):p.quit()
 log.close()
