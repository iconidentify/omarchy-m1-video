import importlib.util,json
from pathlib import Path
p=Path('<HOME>/src/video-m1-client-delivery-20260920/docs/evidence/m1-clients-2026-09-20/verify.py')
spec=importlib.util.spec_from_file_location('evidence',p);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);data=v.load();key='mpv-candidate-h264-vaapi/events.jsonl'
for name in ['wrong-driver','missing-seek','software-fallback','dropped-frame','wrong-picture']:
 changed=dict(data);events=[json.loads(x) for x in data[key].splitlines()]
 if name=='wrong-driver':events[0]['driver_sha256']='0'*64
 if name=='missing-seek':events.pop(next(i for i,e in enumerate(events) if e['kind']=='seek'))
 if name=='software-fallback':next(e for e in events if e['kind']=='player')['identity']['hwdec']='no'
 if name=='dropped-frame':next(e for e in events if e['kind']=='play_sample')['drops']['decode']=1
 changed[key]=('\n'.join(json.dumps(e) for e in events)+'\n').encode()
 if name=='wrong-picture':changed['mpv-candidate-h264-vaapi/seek-0.png']=data['mpv-candidate-h264-vaapi/seek-1.png']
 try:v.verify(changed)
 except AssertionError:print(name,'correctly rejected')
 else:raise AssertionError(name+' accepted')
